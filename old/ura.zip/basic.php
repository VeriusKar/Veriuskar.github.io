<!DOCTYPE html>
<html>
<head>
  <title>Моя первая страница</title>
  <meta charset="utf-8">
  <script src="vy.html"></script>
  <link rel="stylesheet" type="text/css" href="basic.css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300" rel="stylesheet">
</head>
<body>
  <!-- unordered list -->
  <ul id="menu">
    <!-- list item -->
    <li>
      <!-- anchor -->
      <a href="index.html">
        Главная
      </a>
    </li>
    <li>
      <a href="about.html">
        Обо мне
      </a>
    </li>
    <li>
      <!-- <a href="http://yandex.ru">
        Контакты
      </a> -->
      <a href="contacts.html">
        Контакты
      </a>
    </li>
    <li>
      <!-- <a href="http://yandex.ru">
        Контакты
      </a> -->
      <a href="ugadayka.html">
        Угодайка
      </a>
    </li>

  </ul>
  <!-- divider -->
  <div id="content">
    <div class="left">
      <img src="img/image.png">
    </div>
    <div class="right">
      <!-- paragraph -->
      <p>
        Добрый день. Меня зовут Карен Шайбекян. Я - начинающий программист. Я совсем недавно встал на этот путь, но уже успел написать свой первый сайт.
      </p>
      <p>
        В этом мне помог <a href="vy.html" >Владимир Языков</a>
      </p>


    </div>
  </div>

  <div id="footer">
    Все права защищены
  </div>
</body>
</html>